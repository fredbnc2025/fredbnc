import React, { useMemo } from 'react';
import { Compass, Globe, Navigation, MapPin, Shield, Layers, Users, Award, BookOpen } from 'lucide-react';
import { Country } from '../types';
import { NauticalCompass } from './NauticalCompass';
import { getCountryPoliticalStructure } from '../data/politicalDivisions';

interface CountryPdfPage3Props {
  country: Country;
  id?: string;
  theme?: 'light' | 'dark';
}

export const CountryPdfPage3: React.FC<CountryPdfPage3Props> = ({
  country,
  id = `pdf-sheet-p3-${country.id}`,
  theme = 'light'
}) => {
  const isLight = theme === 'light';

  // Political structure
  const structure = useMemo(() => getCountryPoliticalStructure(country), [country]);

  // Format coordinates safely from country.lat and country.lng
  const latitude = typeof country.lat === 'number' ? country.lat : 0;
  const longitude = typeof country.lng === 'number' ? country.lng : 0;

  const latStr = `${Math.abs(latitude).toFixed(2)}° ${
    latitude >= 0 ? 'N (Norte)' : 'S (Sur)'
  }`;
  const lonStr = `${Math.abs(longitude).toFixed(2)}° ${
    longitude >= 0 ? 'E (Este)' : 'O (Oeste)'
  }`;

  const hemisphereNS = latitude >= 0 ? 'Hemisferio Norte (Boreal)' : 'Hemisferio Sur (Austral)';
  const hemisphereEW = longitude >= 0 ? 'Hemisferio Oriental (Este)' : 'Hemisferio Occidental (Oeste)';

  // Density calculation
  const density = country.areaKm2 > 0 ? (country.population / country.areaKm2).toFixed(1) : 'N/D';

  return (
    <div
      id={id}
      className={`relative mx-auto overflow-hidden font-sans select-none print:shadow-none ${
        isLight
          ? 'bg-white text-slate-900 border border-slate-300'
          : 'bg-slate-950 text-slate-100 border border-slate-800'
      }`}
      style={{
        width: '794px',  // Standard printable Letter / A4 portrait width
        height: '1123px', // Standard printable Letter / A4 portrait height
        padding: '24px 28px',
        boxSizing: 'border-box'
      }}
    >
      {/* Decorative Outer Border & Gold/Sky Trim */}
      <div
        className="absolute inset-0 border-4 pointer-events-none"
        style={{ borderColor: isLight ? '#0284c7' : '#0369a1' }}
      />
      <div
        className="absolute inset-[3px] border pointer-events-none"
        style={{ borderColor: isLight ? '#cbd5e1' : '#1e293b' }}
      />

      {/* PAGE HEADER: ENCABEZADO CARTOGRÁFICO Y GEODÉSICO */}
      <div className="relative border-b pb-3 mb-4" style={{ borderColor: isLight ? '#cbd5e1' : '#334155' }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center shadow-md flex-shrink-0"
              style={{
                background: isLight ? '#0284c7' : '#0369a1',
                color: '#ffffff'
              }}
            >
              <Compass className="w-7 h-7" />
            </div>
            <div>
              <p
                className="text-[10px] font-black tracking-widest uppercase"
                style={{ color: isLight ? '#0284c7' : '#38bdf8' }}
              >
                MundoBanderas • Atlas Geodésico & Orientación Náutica
              </p>
              <div className="flex items-baseline gap-3">
                <h1 className="text-2xl font-black tracking-tight" style={{ color: isLight ? '#0f172a' : '#ffffff' }}>
                  {country.nameEs}
                </h1>
                <span className="text-sm font-semibold" style={{ color: isLight ? '#64748b' : '#94a3b8' }}>
                  — Brújula Náutica & Organización Territorial
                </span>
              </div>
              <p className="text-[10.5px] font-medium" style={{ color: isLight ? '#475569' : '#94a3b8' }}>
                Orientación WGS84 • Rosa de los Vientos (N-S-E-O) • Registro de {structure.totalCount} {structure.divisionTypeName}
              </p>
            </div>
          </div>

          {/* Right Header Badges */}
          <div className="flex flex-col items-end gap-1.5">
            <div className="flex items-center gap-2">
              <span
                className="px-3 py-1 rounded-lg text-xs font-bold border shadow-sm"
                style={{
                  background: isLight ? '#ecfdf5' : '#064e3b',
                  borderColor: isLight ? '#a7f3d0' : '#047857',
                  color: isLight ? '#047857' : '#34d399'
                }}
              >
                {country.continent}
              </span>
              <span
                className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold border shadow-sm"
                style={{
                  background: isLight ? '#e0f2fe' : '#082f49',
                  borderColor: isLight ? '#7dd3fc' : '#0369a1',
                  color: isLight ? '#0369a1' : '#38bdf8'
                }}
              >
                {country.code3}
              </span>
            </div>
            <span
              className="text-[9.5px] font-bold px-2 py-0.5 rounded border"
              style={{
                background: isLight ? '#f1f5f9' : '#1e293b',
                borderColor: isLight ? '#cbd5e1' : '#334155',
                color: isLight ? '#64748b' : '#94a3b8'
              }}
            >
              PÁGINA 3 • NAVEGACIÓN & DIVISIÓN TERRITORIAL
            </span>
          </div>
        </div>
      </div>

      {/* TOP SECTION: GRAN BRÚJULA NÁUTICA + ESPECIFICACIONES GEODÉSICAS */}
      <div className="grid grid-cols-12 gap-4 mb-4">
        {/* Left (6 cols): Gran Brújula Náutica SVG */}
        <div
          className="col-span-6 p-4 rounded-2xl border flex flex-col items-center justify-between shadow-sm"
          style={{
            background: isLight ? '#f8fafc' : '#0f172a',
            borderColor: isLight ? '#e2e8f0' : '#1e293b'
          }}
        >
          <div className="w-full flex items-center justify-between border-b pb-2 mb-2" style={{ borderColor: isLight ? '#e2e8f0' : '#1e293b' }}>
            <span className="text-[11px] font-bold uppercase tracking-wider text-sky-600 flex items-center gap-1.5">
              <Compass className="w-4 h-4" /> Rosa de los Vientos
            </span>
            <span className="text-[9.5px] font-mono text-slate-500 font-semibold">
              Rumbo Magnético 000°
            </span>
          </div>

          {/* Compass Graphic */}
          <div className="py-2">
            <NauticalCompass
              size={210}
              theme={theme}
              showDegrees={true}
              countryName={country.nameEs}
            />
          </div>

          <div className="w-full text-center pt-2 border-t text-[10px] text-slate-500" style={{ borderColor: isLight ? '#e2e8f0' : '#1e293b' }}>
            Orientación Geodésica Oficial • Puntos Cardinales <strong>N (Norte) • S (Sur) • E (Este) • O (Oeste)</strong>
          </div>
        </div>

        {/* Right (6 cols): Coordenadas Geográficas, Hemisferios & Datos de Navegación */}
        <div
          className="col-span-6 p-4 rounded-2xl border flex flex-col justify-between shadow-sm"
          style={{
            background: isLight ? '#f8fafc' : '#0f172a',
            borderColor: isLight ? '#e2e8f0' : '#1e293b'
          }}
        >
          <div>
            <div className="flex items-center justify-between border-b pb-2 mb-3" style={{ borderColor: isLight ? '#e2e8f0' : '#1e293b' }}>
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 flex items-center gap-1.5">
                <Globe className="w-4 h-4" /> Posicionamiento Geodésico WGS84
              </span>
              <span className="text-[9.5px] font-mono text-slate-500 font-semibold">
                Datum WGS84
              </span>
            </div>

            <div className="space-y-2.5">
              {/* Capital Coordinates */}
              <div
                className="p-2.5 rounded-xl border flex items-center justify-between"
                style={{
                  background: isLight ? '#ffffff' : '#1e293b',
                  borderColor: isLight ? '#cbd5e1' : '#334155'
                }}
              >
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-red-500" />
                  <div>
                    <p className="text-[9px] text-slate-500 font-semibold">CAPITAL DE ESTADO</p>
                    <p className="text-xs font-bold" style={{ color: isLight ? '#0f172a' : '#ffffff' }}>
                      ★ {country.capitalEs || country.capitalEn}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[9.5px] font-mono font-bold text-sky-600">
                    {latStr}
                  </p>
                  <p className="text-[9.5px] font-mono font-bold text-sky-600">
                    {lonStr}
                  </p>
                </div>
              </div>

              {/* Hemispheres */}
              <div
                className="p-2.5 rounded-xl border flex items-center justify-between"
                style={{
                  background: isLight ? '#ffffff' : '#1e293b',
                  borderColor: isLight ? '#cbd5e1' : '#334155'
                }}
              >
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-sky-500" />
                  <div>
                    <p className="text-[9px] text-slate-500 font-semibold">HEMISFERIOS TERRESTRES</p>
                    <p className="text-[11px] font-bold" style={{ color: isLight ? '#0f172a' : '#ffffff' }}>
                      {hemisphereNS}
                    </p>
                    <p className="text-[10px] text-slate-500">
                      {hemisphereEW}
                    </p>
                  </div>
                </div>
                <span className="text-[9px] font-mono px-2 py-1 rounded bg-sky-500/10 text-sky-600 font-bold">
                  {latitude >= 0 ? 'LAT +' : 'LAT -'}
                </span>
              </div>

              {/* Territorial Regime */}
              <div
                className="p-2.5 rounded-xl border flex items-center justify-between"
                style={{
                  background: isLight ? '#ffffff' : '#1e293b',
                  borderColor: isLight ? '#cbd5e1' : '#334155'
                }}
              >
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-amber-500" />
                  <div>
                    <p className="text-[9px] text-slate-500 font-semibold">RÉGIMEN & ORGANIZACIÓN</p>
                    <p className="text-[11px] font-bold" style={{ color: isLight ? '#0f172a' : '#ffffff' }}>
                      {structure.governmentSystem}
                    </p>
                    <p className="text-[10px] text-slate-500">
                      Articulado en {structure.totalCount} {structure.divisionTypeName}
                    </p>
                  </div>
                </div>
                <span className="text-[9px] font-mono px-2 py-1 rounded bg-amber-500/10 text-amber-600 font-bold">
                  {structure.totalCount} ENT.
                </span>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t text-[10px] text-slate-500 flex justify-between" style={{ borderColor: isLight ? '#e2e8f0' : '#1e293b' }}>
            <span>Superficie: {country.areaKm2.toLocaleString()} km²</span>
            <span>Densidad: {density} hab/km²</span>
          </div>
        </div>
      </div>

      {/* LOWER SECTION: TABLA Y DETALLE DE SUBDIVISIONES POLÍTICAS (DEPARTAMENTOS / ESTADOS / PROVINCIAS) */}
      <div
        className="mb-4 p-4 rounded-2xl border shadow-sm flex-1 flex flex-col justify-between"
        style={{
          background: isLight ? '#f8fafc' : '#0f172a',
          borderColor: isLight ? '#e2e8f0' : '#1e293b'
        }}
      >
        <div>
          <div className="flex items-center justify-between border-b pb-2 mb-3" style={{ borderColor: isLight ? '#e2e8f0' : '#1e293b' }}>
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-sky-600" />
              <span className="text-xs font-bold uppercase tracking-wider" style={{ color: isLight ? '#0284c7' : '#38bdf8' }}>
                Registro Territorial: {structure.countryName} ({structure.totalCount} {structure.divisionTypeName})
              </span>
            </div>
            <span className="text-[10px] font-mono text-slate-500 font-semibold">
              Estructura Administrativa Oficial
            </span>
          </div>

          {/* Subdivisions Grid (Up to 12 representative departments / states) */}
          <div className="grid grid-cols-3 gap-2.5">
            {structure.subdivisions.slice(0, 12).map((sub, sIdx) => {
              const isCapitalRegion = sub.type.toLowerCase().includes('capital') || sub.capital === country.capitalEs;

              return (
                <div
                  key={`sub-p3-${sub.id || sIdx}`}
                  className="p-2.5 rounded-xl border flex flex-col justify-between"
                  style={{
                    background: isLight ? '#ffffff' : '#1e293b',
                    borderColor: isCapitalRegion
                      ? isLight ? '#38bdf8' : '#0284c7'
                      : isLight ? '#e2e8f0' : '#334155'
                  }}
                >
                  <div className="flex items-start justify-between gap-1 mb-1">
                    <div className="flex items-center gap-1.5 overflow-hidden">
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-500 flex-shrink-0" />
                      <p className="text-[10.5px] font-bold truncate" style={{ color: isLight ? '#0f172a' : '#ffffff' }}>
                        {sub.name}
                      </p>
                    </div>
                    {isCapitalRegion && (
                      <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-red-500/10 text-red-600 flex-shrink-0">
                        CAPITAL
                      </span>
                    )}
                  </div>

                  <div className="text-[9.5px] text-slate-500 flex items-center justify-between mt-1">
                    <span className="truncate">★ {sub.capital}</span>
                    {sub.population && (
                      <span className="font-mono text-[9px] font-semibold text-slate-600 dark:text-slate-400">
                        {(sub.population / 1000000).toFixed(1)}M hab.
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Informative Note & Summary */}
        <div
          className="mt-3 pt-2.5 border-t flex items-center justify-between text-[10.5px] text-slate-500"
          style={{ borderColor: isLight ? '#e2e8f0' : '#1e293b' }}
        >
          <div className="flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5 text-sky-500" />
            <span>
              {structure.subdivisions.length > 12
                ? `Mostrando 12 de ${structure.totalCount} ${structure.divisionTypeName.toLowerCase()} principales de ${country.nameEs}.`
                : `Desglose de las ${structure.totalCount} ${structure.divisionTypeName.toLowerCase()} que componen la soberanía de ${country.nameEs}.`}
            </span>
          </div>
          <span className="font-mono font-semibold text-slate-600 dark:text-slate-400">
            SISTEMA: {structure.governmentSystem.toUpperCase()}
          </span>
        </div>
      </div>

      {/* PAGE FOOTER */}
      <div
        className="relative border-t pt-3 flex items-center justify-between text-xs text-slate-500"
        style={{ borderColor: isLight ? '#cbd5e1' : '#334155' }}
      >
        <div className="flex items-center gap-2 font-medium">
          <div
            className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold"
            style={{
              background: isLight ? '#0284c7' : '#0369a1',
              color: '#ffffff'
            }}
          >
            3
          </div>
          <span>
            <strong>MundoBanderas</strong> • Orientación Náutica & Registro Territorial Oficial
          </span>
        </div>
        <div className="flex items-center gap-3 font-mono">
          <span>{country.nameEs.toUpperCase()}</span>
          <span>•</span>
          <span>PÁGINA 3</span>
        </div>
      </div>
    </div>
  );
};
