import React, { useState, useRef } from 'react';
import { Country } from '../types';
import { CountryPdfPage1 } from './CountryPdfPage1';
import { CountryPdfPage2 } from './CountryPdfPage2';
import { CountryPdfPage3 } from './CountryPdfPage3';
import { KdpQuickPreviewModal } from './KdpQuickPreviewModal';
import { AmazonKdpService } from '../services/amazonKdpService';
import { KdpPdfGeneratorService } from '../services/kdpPdfGeneratorService';
import {
  BookOpen,
  ShoppingBag,
  Download,
  CheckCircle2,
  Copy,
  Layers,
  Sparkles,
  FileText,
  DollarSign,
  TrendingUp,
  Tag,
  ShieldCheck,
  Package,
  Compass,
  Award,
  Globe,
  Zap,
  AlertCircle,
  Eye,
  X
} from 'lucide-react';

interface AmazonKdpPublishModalProps {
  isOpen: boolean;
  countries: Country[];
  onClose: () => void;
}

export const AmazonKdpPublishModal: React.FC<AmazonKdpPublishModalProps> = ({
  isOpen,
  countries,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'compilation' | 'preview' | 'metadata' | 'instructions' | 'pricing'>('compilation');
  const [selectedPaper, setSelectedPaper] = useState<'letter' | 'a4'>('letter');
  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [compilingMode, setCompilingMode] = useState<'instant' | 'visual' | 'cover' | 'zip' | null>(null);
  const [compileProgress, setCompileProgress] = useState<{ current: number; total: number; stage: string; currentCountry: string }>({
    current: 0,
    total: 0,
    stage: '',
    currentCountry: ''
  });
  const [compilationDone, setCompilationDone] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [stagingCountry, setStagingCountry] = useState<Country | null>(null);
  const [previewCountryId, setPreviewCountryId] = useState<string>(countries[0]?.id || 'ESP');
  const [previewPageNumber, setPreviewPageNumber] = useState<1 | 2 | 3>(2);
  const [isQuickPreviewOpen, setIsQuickPreviewOpen] = useState<boolean>(false);
  const cancelRef = useRef<{ cancelled: boolean }>({ cancelled: false });

  // Filter or selection for countries
  const [countrySubset, setCountrySubset] = useState<'all' | 'sample10' | 'america' | 'europe' | 'asia' | 'africa' | 'oceania'>('all');

  const filteredCountries = countrySubset === 'all'
    ? countries
    : countrySubset === 'sample10'
    ? countries.slice(0, 10)
    : countrySubset === 'america'
    ? countries.filter((c) => c.continent.includes('América'))
    : countries.filter((c) => c.continent.toLowerCase() === countrySubset.toLowerCase());

  const previewCountry = countries.find(c => c.id === previewCountryId) || filteredCountries[0] || countries[0];

  const metadata = AmazonKdpService.generateListingMetadata(filteredCountries);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleCancelCompilation = () => {
    cancelRef.current.cancelled = true;
    setIsCompiling(false);
    setStagingCountry(null);
  };

  // 1. Instant Direct Vector Generator (Ultra-fast & 100% Reliable con soporte KDP G201857950)
  const handleInstantVectorDownload = async (bleed: boolean = true) => {
    if (isCompiling || filteredCountries.length === 0) return;
    setIsCompiling(true);
    setCompilingMode('instant');
    setCompilationDone(false);
    cancelRef.current.cancelled = false;

    try {
      await KdpPdfGeneratorService.generateInstantVectorPdf(
        filteredCountries,
        selectedPaper,
        (current, total, stage, countryName) => {
          setCompileProgress({ current, total, stage, currentCountry: countryName });
        },
        { bleed }
      );
      setCompilationDone(true);
    } catch (err) {
      console.error('Error en generación vectorial directa:', err);
      alert('Hubo un error al generar el archivo PDF. Intente nuevamente.');
    } finally {
      setIsCompiling(false);
      setCompilingMode(null);
    }
  };

  // 2. Visual DOM High-Fidelity Rendering Generator
  const handleVisualDomDownload = async () => {
    if (isCompiling || filteredCountries.length === 0) return;
    setIsCompiling(true);
    setCompilingMode('visual');
    setCompilationDone(false);
    cancelRef.current.cancelled = false;

    try {
      await KdpPdfGeneratorService.generateVisualDomPdf(
        filteredCountries,
        selectedPaper,
        (country) => setStagingCountry(country),
        (current, total, stage, countryName) => {
          setCompileProgress({ current, total, stage, currentCountry: countryName });
        },
        cancelRef.current
      );
      setCompilationDone(true);
    } catch (err: any) {
      if (cancelRef.current.cancelled) return;
      console.error('Error en renderizado visual:', err);
      // Automatic fallback offer
      const retryVector = window.confirm(
        'El renderizado gráfico intensivo tardó demasiado o tuvo una restricción de memoria en el navegador. ¿Deseas descargar el libro inmediatamente usando el Generador Vectorial Ultra-Rápido?'
      );
      if (retryVector) {
        handleInstantVectorDownload();
      }
    } finally {
      setIsCompiling(false);
      setCompilingMode(null);
      setStagingCountry(null);
    }
  };

  // 3. Full Wrap Cover Generator (Portada + Lomo exacto + Contraportada KDP)
  const handleFullWrapCoverDownload = async () => {
    if (isCompiling || filteredCountries.length === 0) return;
    setIsCompiling(true);
    setCompilingMode('cover');
    setCompilationDone(false);
    cancelRef.current.cancelled = false;

    try {
      await KdpPdfGeneratorService.generateFullWrapCoverPdf(
        filteredCountries,
        selectedPaper,
        (current, total, stage, countryName) => {
          setCompileProgress({ current, total, stage, currentCountry: countryName });
        }
      );
      setCompilationDone(true);
    } catch (err) {
      console.error('Error en generación de cubierta KDP:', err);
      alert('Hubo un error al generar la cubierta KDP. Intente nuevamente.');
    } finally {
      setIsCompiling(false);
      setCompilingMode(null);
    }
  };

  // 4. Paquete Automático 1-Clic Todo-en-Uno (ZIP) para Amazon KDP
  const handleKdpZipBundleDownload = async () => {
    if (isCompiling || filteredCountries.length === 0) return;
    setIsCompiling(true);
    setCompilingMode('zip');
    setCompilationDone(false);
    cancelRef.current.cancelled = false;

    try {
      await KdpPdfGeneratorService.generateKdpZipPackage(
        filteredCountries,
        selectedPaper,
        (current, total, stage, countryName) => {
          setCompileProgress({ current, total, stage, currentCountry: countryName });
        }
      );
      setCompilationDone(true);
    } catch (err) {
      console.error('Error en generación del paquete KDP ZIP:', err);
      alert('Hubo un error al generar el paquete ZIP. Intente nuevamente.');
    } finally {
      setIsCompiling(false);
      setCompilingMode(null);
    }
  };

  return (
    <div
      id="amazon-kdp-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
    >
      <div
        id="amazon-kdp-modal-card"
        className="relative w-full max-w-6xl h-[94vh] bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* HEADER BAR */}
        <div className="flex flex-wrap items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/95 gap-3">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-yellow-500 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/20 font-black">
              <ShoppingBag className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white tracking-tight">
                  Compilador Editorial para Amazon KDP (Kindle Direct Publishing)
                </h2>
                <span className="text-[10px] font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  Listado Comercial Automático
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Genera el manuscrito PDF completo con banderas vectoriales SVG incrustadas, nombres oficiales y ficha KDP lista para venta en Amazon
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsQuickPreviewOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 hover:text-amber-200 text-xs font-bold border border-amber-500/40 transition-all cursor-pointer shadow-sm"
              title="Abrir ventana emergente con la previsualización interactiva del libro PDF completo"
            >
              <Eye className="w-3.5 h-3.5 text-amber-400" />
              <span>Vista Previa del Libro</span>
            </button>
            <button
              onClick={() => AmazonKdpService.downloadKdpManifest(filteredCountries)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold border border-slate-700 transition-all cursor-pointer"
              title="Descargar archivo JSON con título, descripción y palabras clave para la API de Amazon"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>Exportar JSON Metadatos</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              aria-label="Cerrar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* NAVIGATION TABS */}
        <div className="flex items-center px-6 border-b border-slate-800 bg-slate-900/60 overflow-x-auto no-scrollbar gap-2 py-2">
          <button
            onClick={() => setActiveTab('compilation')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'compilation'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>1. Compilar Libro PDF ({filteredCountries.length * 3 + 2} Páginas)</span>
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'preview'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>2. Vista Previa de Mapas SVG & Páginas</span>
          </button>

          <button
            onClick={() => setActiveTab('metadata')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'metadata'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>3. Título, Sinopsis & SEO</span>
          </button>

          <button
            onClick={() => setActiveTab('pricing')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'pricing'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>4. Precios & Regalías KDP</span>
          </button>

          <button
            onClick={() => setActiveTab('instructions')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'instructions'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>5. Guía de Publicación</span>
          </button>
        </div>

        {/* TAB CONTENTS */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-950/70">
          {/* TAB 1: COMPILATION */}
          {activeTab === 'compilation' && (
            <div className="max-w-4xl mx-auto space-y-6">
              {/* Region Filter & Paper Options */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Globe className="w-4 h-4 text-sky-400" />
                      Selección de Países a Compilar
                    </span>
                    <span className="text-xs font-mono font-bold text-amber-400">
                      {filteredCountries.length} Países ({filteredCountries.length + Math.max(1, Math.ceil(filteredCountries.length / 44)) + 4} Páginas Totales)
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-1.5 text-xs">
                    {[
                      { id: 'all', label: 'Todos los Países' },
                      { id: 'sample10', label: 'Muestra (10 Países)' },
                      { id: 'america', label: 'América' },
                      { id: 'europe', label: 'Europa' },
                      { id: 'asia', label: 'Asia' },
                      { id: 'africa', label: 'África' },
                      { id: 'oceania', label: 'Oceanía' }
                    ].map((scope) => (
                      <button
                        key={scope.id}
                        onClick={() => setCountrySubset(scope.id as any)}
                        className={`p-2 rounded-xl font-semibold transition-all text-center cursor-pointer border ${
                          countrySubset === scope.id
                            ? 'bg-sky-500 text-white border-sky-400 shadow-sm'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                        }`}
                      >
                        {scope.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-amber-400" />
                    Formato de Interior Amazon KDP
                  </span>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      onClick={() => setSelectedPaper('letter')}
                      className={`p-3 rounded-xl border flex flex-col items-start gap-1 cursor-pointer transition-all ${
                        selectedPaper === 'letter'
                          ? 'bg-amber-500/10 border-amber-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span className="font-bold text-amber-300">Carta / Letter (Bond)</span>
                      <span className="text-[11px] text-slate-400">8.5 x 11 in (21.59 x 27.94 cm)</span>
                      <span className="text-[10px] text-emerald-400 font-semibold">★ Estándar Amazon US/MX</span>
                    </button>

                    <button
                      onClick={() => setSelectedPaper('a4')}
                      className={`p-3 rounded-xl border flex flex-col items-start gap-1 cursor-pointer transition-all ${
                        selectedPaper === 'a4'
                          ? 'bg-amber-500/10 border-amber-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span className="font-bold text-sky-300">Estándar A4</span>
                      <span className="text-[11px] text-slate-400">21.0 x 29.7 cm</span>
                      <span className="text-[10px] text-slate-400 font-semibold">Ideal Amazon España/Europa</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Book Overview Showcase */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    Estructura del Libro para Amazon KDP
                  </h3>
                  <span className="text-xs bg-slate-800 text-slate-300 px-3 py-1 rounded-full border border-slate-700">
                    Banderas SVG + Nombres + Portada, ISBN e Índice
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400 flex-shrink-0">
                      <Award className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white mb-0.5">Banderas Vectoriales SVG</h4>
                      <p className="text-slate-400 text-[11px] leading-relaxed">
                        Pabellón oficial de cada nación incrustado a máxima resolución (300+ DPI) con proporción geométrica exacta y marco protector para campos blancos.
                      </p>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950/80 border border-sky-500/30 flex items-start gap-3 shadow-md shadow-sky-500/5">
                    <div className="p-2 rounded-lg bg-sky-500/20 text-sky-300 flex-shrink-0">
                      <Globe className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sky-300 mb-0.5">Nombres Oficiales & Soberanía</h4>
                      <p className="text-slate-400 text-[11px] leading-relaxed">
                        Nombre destacado en español, denominación en inglés, código ISO 3166-1, capital nacional, población, superficie, moneda e idiomas de estado.
                      </p>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-start gap-3">
                    <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 flex-shrink-0">
                      <Compass className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white mb-0.5">Estructura Editorial KDP</h4>
                      <p className="text-slate-400 text-[11px] leading-relaxed">
                        Portada interior de lujo, página de créditos legales con ISBN, tabla de contenidos paginada, apéndice técnico y contraportada con código de barras.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Compilation action button & Progress */}
                <div className="pt-3 border-t border-slate-800 flex flex-col items-center gap-3">
                  {isCompiling ? (
                    <div className="w-full space-y-3 p-4 rounded-2xl bg-slate-900 border border-amber-500/30">
                      <div className="flex items-center justify-between text-xs text-slate-300">
                        <span className="font-bold text-amber-400 animate-pulse flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                          {compileProgress.stage || 'Compilando manuscrito...'}
                        </span>
                        <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-amber-300">
                          {compileProgress.current} / {compileProgress.total} páginas
                        </span>
                      </div>
                      <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-200"
                          style={{
                            width: `${(compileProgress.current / Math.max(1, compileProgress.total)) * 100}%`
                          }}
                        />
                      </div>
                      <div className="flex justify-end">
                        <button
                          onClick={handleCancelCompilation}
                          className="text-xs text-rose-400 hover:text-rose-300 underline cursor-pointer"
                        >
                          Cancelar compilación
                        </button>
                      </div>
                    </div>
                  ) : compilationDone ? (
                    <div className="w-full p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                        <div>
                          <p className="font-bold text-white">¡Archivo PDF descargado con éxito!</p>
                          <p className="text-emerald-400/80">
                            Manuscrito completo de {filteredCountries.length + Math.max(1, Math.ceil(filteredCountries.length / 44)) + 4} páginas con banderas SVG y nombres oficiales listo para venta en Amazon KDP.
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={handleInstantVectorDownload}
                          className="px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold cursor-pointer transition-all shadow"
                        >
                          Descargar Otra Copia
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="w-full space-y-3">
                      {/* PAQUETE AUTOMÁTICO 1-CLIC (ZIP) PARA AMAZON KDP */}
                      <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-500/15 to-yellow-500/15 border-2 border-amber-500/60 shadow-xl shadow-amber-500/10 space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-extrabold uppercase tracking-wider bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full font-mono">
                                Recomendado para Publicar
                              </span>
                              <span className="text-xs text-amber-300 font-bold">Cero Trabas Técnicas</span>
                            </div>
                            <h4 className="text-sm font-black text-white mt-1">
                              Paquete Todo-en-Uno para Amazon KDP (Archivo ZIP)
                            </h4>
                            <p className="text-[11px] text-slate-300 leading-relaxed mt-0.5">
                              Incluye: 1) Manuscrito Interior clasificado en 5 continentes (PDF), 2) Cubierta Completa con lomo de {metadata.bookSpecifications.spineWidthMm} mm (PDF), 3) Metadatos (JSON), 4) Textos para copiar y pegar (TXT), y 5) Guía de subida rápida.
                            </p>
                          </div>

                          <button
                            onClick={handleKdpZipBundleDownload}
                            className="py-3 px-5 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/30 transition-all flex items-center justify-center gap-2 cursor-pointer flex-shrink-0"
                          >
                            <Package className="w-4 h-4 text-slate-950" />
                            <span>Descargar Paquete ZIP (1-Clic)</span>
                          </button>
                        </div>
                      </div>

                      {/* ACCIONES INDIVIDUALES (INTERIOR, CUBIERTA, VISTA PREVIA) */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                        {/* BOTÓN INTERIOR CON SANGRÍA (RECOMENDADO KDP) */}
                        <button
                          onClick={() => handleInstantVectorDownload(true)}
                          className="py-3 px-3 rounded-xl bg-slate-900 hover:bg-slate-850 text-white font-bold text-xs border border-amber-500/50 hover:border-amber-400 transition-all flex items-center gap-2.5 cursor-pointer text-left"
                          title="Formato con Sangría 8.625 x 11.25 in conforme a Guía KDP G201857950. En KDP selecciona 'Con sangría'."
                        >
                          <Zap className="w-4 h-4 text-amber-400 flex-shrink-0" />
                          <div>
                            <div className="text-white font-bold leading-tight flex items-center gap-1.5">
                              <span>Interior Con Sangría</span>
                              <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1 py-0.2 rounded font-mono">KDP</span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-normal mt-0.5">
                              8.625" × 11.25" • {metadata.bookSpecifications.pageCount} Págs.
                            </div>
                          </div>
                        </button>

                        {/* BOTÓN INTERIOR SIN SANGRÍA */}
                        <button
                          onClick={() => handleInstantVectorDownload(false)}
                          className="py-3 px-3 rounded-xl bg-slate-900 hover:bg-slate-850 text-white font-bold text-xs border border-slate-700 hover:border-slate-500 transition-all flex items-center gap-2.5 cursor-pointer text-left"
                          title="Formato Sin Sangría 8.5 x 11.0 in con márgenes seguros. En KDP selecciona 'Sin sangría'."
                        >
                          <FileText className="w-4 h-4 text-slate-300 flex-shrink-0" />
                          <div>
                            <div className="text-white font-bold leading-tight">Interior Sin Sangría</div>
                            <div className="text-[10px] text-slate-400 font-normal mt-0.5">
                              8.5" × 11.0" • {metadata.bookSpecifications.pageCount} Págs.
                            </div>
                          </div>
                        </button>

                        {/* BOTÓN CUBIERTA COMPLETA PDF */}
                        <button
                          onClick={handleFullWrapCoverDownload}
                          className="py-3 px-3 rounded-xl bg-slate-900 hover:bg-slate-850 text-white font-bold text-xs border border-slate-700 hover:border-sky-500/50 transition-all flex items-center gap-2.5 cursor-pointer text-left"
                        >
                          <Layers className="w-4 h-4 text-sky-400 flex-shrink-0" />
                          <div>
                            <div className="text-white font-bold leading-tight">Cubierta Completa</div>
                            <div className="text-[10px] text-slate-400 font-normal mt-0.5">
                              Lomo exacto {metadata.bookSpecifications.spineWidthMm} mm + Sangría
                            </div>
                          </div>
                        </button>

                        {/* BOTÓN VISTA PREVIA */}
                        <button
                          onClick={() => setIsQuickPreviewOpen(true)}
                          className="py-3 px-3 rounded-xl bg-slate-900 hover:bg-slate-850 text-amber-300 hover:text-white font-bold text-xs border border-slate-700 hover:border-amber-500/50 transition-all flex items-center gap-2.5 cursor-pointer text-left"
                        >
                          <Eye className="w-4 h-4 text-amber-400 flex-shrink-0" />
                          <div>
                            <div className="font-bold leading-tight">Vista Previa Editorial</div>
                            <div className="text-[10px] text-slate-400 font-normal mt-0.5">Examinar páginas del libro</div>
                          </div>
                        </button>
                      </div>

                      {/* BOTÓN OPCIONAL RENDER DOM */}
                      <div className="flex justify-center">
                        <button
                          onClick={handleVisualDomDownload}
                          className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1.5 py-1 px-3 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                        >
                          <Download className="w-3.5 h-3.5 text-slate-500" />
                          <span>Descargar copia con renderizado visual progresivo DOM</span>
                        </button>
                      </div>
                    </div>
                  )}
                  <p className="text-[11px] text-slate-500 text-center">
                    El archivo se compila automáticamente con banderas vectoriales SVG incrustadas, nombres oficiales en español e inglés, ficha de soberanía, índice general, ISBN y contraportada apto para impresión bajo demanda (*Print on Demand*).
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: LIVE PREVIEW OF PAGES & SVG MAPS */}
          {activeTab === 'preview' && (
            <div className="max-w-4xl mx-auto space-y-4">
              {/* Header Selector */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 whitespace-nowrap">
                    <Globe className="w-4 h-4 text-sky-400" />
                    País de Muestra:
                  </span>
                  <select
                    value={previewCountryId}
                    onChange={(e) => setPreviewCountryId(e.target.value)}
                    className="bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-xl px-3 py-2 font-medium focus:outline-none focus:border-amber-500 cursor-pointer w-full sm:w-64"
                  >
                    {filteredCountries.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.nameEs} ({c.code3}) — {c.continent}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Page indicator */}
                <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 w-full sm:w-auto justify-center">
                  <span className="px-3 py-1.5 rounded-lg text-xs font-bold bg-sky-500 text-white shadow-sm">
                    Ficha Oficial: Solo Bandera
                  </span>
                </div>
              </div>

              {/* Preview Container Frame */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center justify-center overflow-x-auto">
                <div className="text-center mb-3">
                  <span className="text-xs font-bold text-amber-400">
                    {previewCountry.nameEs.toUpperCase()} • FICHA OFICIAL KDP (SOLO BANDERA)
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Pabellón Nacional Oficial de Estado a alta resolución vectorial
                  </p>
                </div>

                <div className="shadow-2xl rounded-lg overflow-hidden border border-slate-700 bg-white" style={{ maxWidth: '794px', width: '100%' }}>
                  <CountryPdfPage1 country={previewCountry} id={`kdp-preview-p1-${previewCountry.id}`} theme="light" />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: METADATA & LISTING COPY */}
          {activeTab === 'metadata' && (
            <div className="max-w-4xl mx-auto space-y-5">
              {/* Title & Subtitle */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Tag className="w-4 h-4" />
                    Título y Subtítulo del Libro (Optimizado para Búsquedas en Amazon)
                  </span>
                  <button
                    onClick={() => copyToClipboard(metadata.title, 'title')}
                    className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-750 px-2.5 py-1 rounded-lg cursor-pointer"
                  >
                    {copiedKey === 'title' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'title' ? 'Copiado' : 'Copiar Título'}</span>
                  </button>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-sm font-bold text-white">
                  {metadata.title}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-xs text-slate-400 font-semibold">Subtítulo:</span>
                  <button
                    onClick={() => copyToClipboard(metadata.subtitle, 'subtitle')}
                    className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-750 px-2.5 py-1 rounded-lg cursor-pointer"
                  >
                    {copiedKey === 'subtitle' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'subtitle' ? 'Copiado' : 'Copiar Subtítulo'}</span>
                  </button>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 leading-relaxed">
                  {metadata.subtitle}
                </div>
              </div>

              {/* Description & Bullet Points */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-sky-400 uppercase tracking-wider flex items-center gap-1.5">
                    <FileText className="w-4 h-4" />
                    Descripción Comercial para la Ficha de Producto (Amazon HTML Ready)
                  </span>
                  <button
                    onClick={() => copyToClipboard(metadata.descriptionHtml, 'desc')}
                    className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-750 px-2.5 py-1 rounded-lg cursor-pointer"
                  >
                    {copiedKey === 'desc' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'desc' ? 'HTML Copiado' : 'Copiar HTML Completo'}</span>
                  </button>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 max-h-48 overflow-y-auto font-mono whitespace-pre-wrap leading-relaxed">
                  {metadata.descriptionHtml}
                </div>
              </div>

              {/* Keywords & Categories */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                      7 Palabras Clave KDP (Keywords)
                    </span>
                    <button
                      onClick={() => copyToClipboard(metadata.keywords.join(', '), 'kw')}
                      className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Copiar Todas</span>
                    </button>
                  </div>
                  <div className="space-y-1.5">
                    {metadata.keywords.map((kw, i) => (
                      <div key={i} className="flex items-center justify-between p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                        <span className="text-slate-300">{i + 1}. {kw}</span>
                        <button
                          onClick={() => copyToClipboard(kw, `kw-${i}`)}
                          className="text-[10px] text-slate-500 hover:text-sky-400 font-mono"
                        >
                          {copiedKey === `kw-${i}` ? '✓' : 'copiar'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                  <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">
                    Categorías BISAC Recomendadas
                  </span>
                  <div className="space-y-1.5">
                    {metadata.categories.map((cat, i) => (
                      <div key={i} className="p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300">
                        📁 {cat}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PRICING & ROYALTIES */}
          {activeTab === 'pricing' && (
            <div className="max-w-4xl mx-auto space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
                  <p className="text-xs text-slate-400 font-semibold uppercase">Precio Sugerido de Venta</p>
                  <p className="text-3xl font-black text-amber-400">$24.99 USD</p>
                  <p className="text-[11px] text-slate-500">O 22,99 € en Amazon Europa</p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-1">
                  <p className="text-xs text-slate-400 font-semibold uppercase">Costo Impresión a Color KDP</p>
                  <p className="text-3xl font-black text-slate-300">~$8.50 USD</p>
                  <p className="text-[11px] text-slate-500">Premium Color Interior (Papel Bond)</p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/30 bg-emerald-950/20 text-center space-y-1">
                  <p className="text-xs text-emerald-400 font-semibold uppercase">Ganancia Neta Estimada (70%)</p>
                  <p className="text-3xl font-black text-emerald-400">+$12.45 USD</p>
                  <p className="text-[11px] text-emerald-500/80">Por cada ejemplar vendido en Amazon</p>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs text-slate-300 leading-relaxed">
                <h4 className="font-bold text-white text-sm flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  Estrategia de Monetización Automática
                </h4>
                <ul className="list-disc pl-5 space-y-1.5 text-slate-400">
                  <li>
                    <strong>Amazon KDP Print on Demand (Tapa Blanda / Tapa Dura):</strong> No requiere inventario previo ni inversión inicial. Amazon imprime, encuaderna y despacha cada libro al cliente cuando realiza la compra.
                  </li>
                  <li>
                    <strong>Versión Digital Kindle / PDF Descargable:</strong> Puedes comercializar adicionalmente la versión digital como eBook interactivo a $9.99 USD con un 70% de regalías ($6.99 de beneficio neto directo).
                  </li>
                  <li>
                    <strong>Mercados Internacionales Activos:</strong> Venta simultánea en Amazon.com (EE.UU.), Amazon.es (España), Amazon.com.mx (México), Amazon.co.uk (Reino Unido), Amazon.de, Amazon.fr y Amazon.jp.
                  </li>
                </ul>
              </div>
            </div>
          )}

          {/* TAB 4: PUBLISHING STEP-BY-STEP GUIDE */}
          {activeTab === 'instructions' && (
            <div className="max-w-4xl mx-auto space-y-4">
              <div className="p-4 rounded-2xl bg-sky-950/40 border border-sky-500/30 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-sky-400 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-sky-200 leading-relaxed">
                  <p className="font-bold text-white mb-1">Publicación Automática en Amazon KDP (Kindle Direct Publishing):</p>
                  Sigue estos 4 pasos rápidos para publicar y comenzar a recibir ventas globales en menos de 24 a 48 horas.
                </div>
              </div>

              <div className="space-y-3 text-xs">
                {[
                  {
                    step: '1',
                    title: 'Acceder a tu cuenta de Amazon KDP',
                    desc: 'Ingresa a kdp.amazon.com con tu cuenta de Amazon existente. Haz clic en el botón amarillo "+ Crear" y selecciona "Libro de tapa blanda" (Paperback).'
                  },
                  {
                    step: '2',
                    title: 'Pegar los Metadatos Copiados',
                    desc: 'Copia el Título, Subtítulo, Descripción HTML y las 7 Palabras Clave generadas en la pestaña "2. Metadatos" de este modal.'
                  },
                  {
                    step: '3',
                    title: 'Cargar el Manuscrito PDF y la Cubierta (Guía Amazon KDP G201857950)',
                    desc: 'En la sección "Contenido del libro de tapa blanda", configura: 1) Tipo de tinta: "Interior a todo color de primera calidad con papel blanco". 2) Tamaño: 8.5 x 11 pulgadas (21.59 x 27.94 cm). 3) Ajustes de sangría: Si subes el archivo "Interior Con Sangría" (8.625 x 11.25 in, Recomendado), marca "Con sangría" (Bleed). Si subes el archivo "Interior Sin Sangría" (8.5 x 11.0 in), marca "Sin sangría" (No Bleed). 4) Acabado de la cubierta: Brillo o Mate según tu preferencia. 5) Sube el PDF del Manuscrito Interior (márgenes con medianil de 19.05 mm para 265 páginas y fuentes TrueType 100% incrustadas) y en "Cubierta del libro" sube el PDF de Cubierta Completa.'
                  },
                  {
                    step: '4',
                    title: 'Fijar Precios y Publicar',
                    desc: 'Establece el precio recomendado ($24.99 USD) y marca la distribución ampliada. Haz clic en "Publicar tu libro de tapa blanda". Amazon lo revisará y estará en venta en 24 horas.'
                  }
                ].map((item) => (
                  <div key={item.step} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-start gap-3.5">
                    <div className="w-7 h-7 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold flex items-center justify-center flex-shrink-0 text-sm">
                      {item.step}
                    </div>
                    <div>
                      <h4 className="font-bold text-white mb-1">{item.title}</h4>
                      <p className="text-slate-400 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* DYNAMIC STAGING CONTAINER (RENDERIZA SÓLO 1 PAÍS A LA VEZ) */}
        {stagingCountry && (
          <div
            id="kdp-dynamic-staging-container"
            className="fixed -left-[9999px] top-0 opacity-100 pointer-events-none bg-white z-0"
            style={{ width: '794px' }}
          >
            <CountryPdfPage1
              country={stagingCountry}
              id="kdp-active-staging-p1"
              theme="light"
            />
          </div>
        )}
      </div>

      {/* QUICK PREVIEW POPUP MODAL */}
      <KdpQuickPreviewModal
        isOpen={isQuickPreviewOpen}
        countries={filteredCountries}
        paperFormat={selectedPaper}
        onClose={() => setIsQuickPreviewOpen(false)}
        onDownloadInstant={() => {
          setIsQuickPreviewOpen(false);
          handleInstantVectorDownload();
        }}
        onDownloadVisual={() => {
          setIsQuickPreviewOpen(false);
          handleVisualDomDownload();
        }}
      />
    </div>
  );
};
