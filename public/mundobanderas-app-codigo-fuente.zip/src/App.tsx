import React, { useState, useEffect } from 'react';
import { Country, ViewMode, UserSubscription, SubscriptionPlanId } from './types';
import { countryService } from './services/countryService';
import { subscriptionService } from './services/subscriptionService';
import { FlagsGallery } from './components/FlagsGallery';
import { FlagComparator } from './components/FlagComparator';
import { FlagQuiz } from './components/FlagQuiz';
import { FlagCreator } from './components/FlagCreator';
import { VexillologyGuide } from './components/VexillologyGuide';
import { FlagDetailModal } from './components/FlagDetailModal';
import { SubscriptionModal } from './components/SubscriptionModal';
import { CountryPdfModal } from './components/CountryPdfModal';
import { AmazonKdpPublishModal } from './components/AmazonKdpPublishModal';
import { SellAppModal } from './components/SellAppModal';
import {
  Flag,
  Grid,
  Globe,
  Scale,
  Gamepad2,
  Palette,
  BookOpen,
  Search,
  Shuffle,
  Sparkles,
  Download,
  Award,
  Crown,
  Zap,
  FileText,
  ShoppingBag,
  Package
} from 'lucide-react';

export default function App() {
  const [countries, setCountries] = useState<Country[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [viewMode, setViewMode] = useState<ViewMode>('gallery');
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [isSubModalOpen, setIsSubModalOpen] = useState<boolean>(false);
  const [subModalInitialPlan, setSubModalInitialPlan] = useState<SubscriptionPlanId>('annual');
  const [userSub, setUserSub] = useState<UserSubscription>(subscriptionService.getSubscription());
  const [comparisonSelectedCountries, setComparisonSelectedCountries] = useState<Country[]>([]);
  const [quickSearchTerm, setQuickSearchTerm] = useState<string>('');
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);
  const [pdfSelectedCountry, setPdfSelectedCountry] = useState<Country | null>(null);
  const [isAmazonKdpModalOpen, setIsAmazonKdpModalOpen] = useState<boolean>(false);
  const [isSellModalOpen, setIsSellModalOpen] = useState<boolean>(false);

  useEffect(() => {
    const unsub = subscriptionService.subscribe(setUserSub);
    return unsub;
  }, []);

  // Load countries via CountryService
  useEffect(() => {
    const loadCountries = async () => {
      setIsLoading(true);
      try {
        const data = await countryService.getCountries();
        setCountries(data);
        if (data.length > 0) {
          const defaultCountry = data.find((c) => c.id === 'es') || data[0];
          setSelectedCountry(defaultCountry);
        }
      } catch (err) {
        console.error('Error al inicializar CountryService:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadCountries();
  }, []);

  // Open full details modal
  const handleOpenDetails = (country: Country) => {
    setSelectedCountry(country);
    setIsModalOpen(true);
  };

  // Compare country in comparator view
  const handleCompareWith = (country: Country) => {
    // Find another interesting country to compare with
    const other = countries.find(
      (c) =>
        c.id !== country.id &&
        (c.continent === country.continent || c.colors.some((col) => country.colors.includes(col)))
    ) || countries[0];

    setComparisonSelectedCountries([country, other]);
    setViewMode('comparator');
  };

  // Quick Random Flag
  const handleRandomFlag = () => {
    if (countries.length === 0) return;
    const random = countries[Math.floor(Math.random() * countries.length)];
    setSelectedCountry(random);
    setIsModalOpen(true);
  };

  // Open PDF Sheet Modal
  const handleOpenPdfModal = (country?: Country) => {
    const target = country || selectedCountry || (countries.length > 0 ? countries[0] : null);
    if (target) {
      setPdfSelectedCountry(target);
      setIsPdfModalOpen(true);
    }
  };

  // Quick search results
  const quickSearchResults = quickSearchTerm.trim()
    ? countryService.filterCountries(countries, { searchTerm: quickSearchTerm }).slice(0, 6)
    : [];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-sky-500 selection:text-white font-sans antialiased">
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-xl border-b border-slate-800/80 px-4 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand / Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500 via-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-sky-500/20 border border-white/20">
            <Flag className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
              MundoBanderas
              <span className="text-[10px] font-mono font-bold text-sky-400 bg-sky-950/80 border border-sky-500/30 px-2 py-0.5 rounded-full">
                SVG & Vexilología
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Enciclopedia de Banderas Vectoriales del Mundo, Cartografía y Publicación Editorial
            </p>
          </div>
        </div>

        {/* Quick Country Search Bar */}
        <div className="relative flex-1 max-w-xs md:max-w-sm hidden sm:block">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={quickSearchTerm}
              onChange={(e) => setQuickSearchTerm(e.target.value)}
              placeholder="Buscar bandera, país o ISO..."
              className="w-full bg-slate-900 border border-slate-700/80 rounded-2xl pl-9 pr-4 py-1.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500 transition-all"
            />
          </div>

          {/* Quick Search Dropdown */}
          {quickSearchResults.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden z-50 divide-y divide-slate-800">
              {quickSearchResults.map((country) => (
                <button
                  key={country.id}
                  onClick={() => {
                    handleOpenDetails(country);
                    setQuickSearchTerm('');
                  }}
                  className="w-full px-4 py-2.5 flex items-center justify-between hover:bg-slate-800 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={`https://flagcdn.com/${country.id}.svg`}
                      alt={country.nameEs}
                      className="w-7 h-5 object-cover rounded shadow-sm border border-white/10"
                    />
                    <div>
                      <span className="text-sm font-semibold text-white">{country.nameEs}</span>
                      <p className="text-[11px] text-slate-400">{country.continent} • {country.capitalEs}</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-sky-400 bg-sky-950 px-2 py-0.5 rounded border border-sky-500/20">
                    {country.code3}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action: Quick Random Flag, Vender App (ZIP) & Amazon KDP Publisher Button */}
        <div className="flex items-center gap-2">
          {/* Direct ZIP Package Download for Selling the App */}
          <button
            onClick={() => setIsSellModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-xs font-bold bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-400 text-white shadow-lg shadow-emerald-600/25 transition-all cursor-pointer"
            title="Descargar paquete ZIP completo de la aplicación (código, base de datos y guías) para venderla"
          >
            <Package className="w-3.5 h-3.5 text-emerald-200" />
            <span className="hidden sm:inline">Vender App</span>
            <span className="bg-slate-950/20 text-emerald-100 px-1.5 py-0.5 rounded text-[10px] font-black">
              ZIP
            </span>
          </button>

          {/* Direct Amazon KDP One-Click Publisher */}
          <button
            onClick={() => setIsAmazonKdpModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl text-xs font-extrabold bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 shadow-lg shadow-amber-500/20 hover:shadow-amber-500/30 transition-all cursor-pointer"
            title="Descargar libro en 1 solo PDF con todas las banderas y metadatos listos para subir y vender en Amazon KDP"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-slate-950 fill-slate-950" />
            <span className="hidden sm:inline">Vender en Amazon KDP</span>
            <span className="sm:hidden">Amazon</span>
            <span className="bg-slate-950/20 text-slate-950 px-1.5 py-0.5 rounded text-[10px] font-black">
              1 PDF
            </span>
          </button>

          <button
            onClick={handleRandomFlag}
            className="hidden md:flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-800 hover:border-slate-700 transition-all cursor-pointer"
            title="Abrir una bandera aleatoria del mundo"
          >
            <Shuffle className="w-3.5 h-3.5 text-amber-400" />
            <span>Bandera al Azar</span>
          </button>

          {/* SaaS Pro Tier Button */}
          {userSub.isPro ? (
            <button
              onClick={() => {
                setSubModalInitialPlan('annual');
                setIsSubModalOpen(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl text-xs font-extrabold bg-gradient-to-r from-amber-500/20 to-yellow-500/20 hover:from-amber-500/30 hover:to-yellow-500/30 text-amber-300 border border-amber-500/40 shadow-lg shadow-amber-500/10 transition-all cursor-pointer animate-pulse"
              title="Tu cuenta tiene acceso Pro Ilimitado. Clic para ver detalles."
            >
              <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span>PRO ACTIVO</span>
            </button>
          ) : (
            <button
              onClick={() => {
                setSubModalInitialPlan('annual');
                setIsSubModalOpen(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-2xl text-xs font-extrabold bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-slate-600 transition-all cursor-pointer"
              title="Ver Planes Pro (Desde $4.99/mes o $29/año)"
            >
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>Planes Pro</span>
            </button>
          )}
        </div>

        {/* View Mode Navigation Tabs */}
        <nav className="flex items-center p-1 bg-slate-900/90 border border-slate-800 rounded-2xl overflow-x-auto no-scrollbar">
          <button
            onClick={() => setViewMode('gallery')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              viewMode === 'gallery'
                ? 'bg-sky-500 text-white shadow-md shadow-sky-500/25'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Catálogo SVG</span>
          </button>

          <button
            onClick={() => setViewMode('comparator')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              viewMode === 'comparator'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/25'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Scale className="w-3.5 h-3.5" />
            <span>Comparador Vexilológico</span>
          </button>

          <button
            onClick={() => setViewMode('quiz')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              viewMode === 'quiz'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/25'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            <span>Trivia & Juegos</span>
          </button>

          <button
            onClick={() => setViewMode('creator')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              viewMode === 'creator'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/25'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Taller Creador</span>
          </button>

          <button
            onClick={() => setViewMode('vexillology')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              viewMode === 'vexillology'
                ? 'bg-amber-600 text-white shadow-md shadow-amber-600/25'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Enciclopedia</span>
          </button>

          {/* Direct Fichas PDF Quick Access */}
          <button
            onClick={() => handleOpenPdfModal()}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap bg-gradient-to-r from-amber-500/20 to-yellow-500/20 hover:from-amber-500/30 hover:to-yellow-500/30 text-amber-300 border border-amber-500/40 shadow-sm transition-all cursor-pointer"
            title="Generador de Fichas Vexilológicas en PDF (2 páginas por país tamaño Papel Bond / Carta)"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>Fichas PDF (Bond)</span>
          </button>
        </nav>
      </header>

      {/* Main Content Workspace */}
      <main className="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto flex flex-col">
        {isLoading ? (
          <div className="flex-1 flex flex-col items-center justify-center min-h-[450px] gap-4">
            <div className="w-12 h-12 rounded-full border-4 border-sky-500/30 border-t-sky-400 animate-spin" />
            <p className="text-sm font-medium text-slate-400">
              Cargando catálogo de banderas vectoriales SVG y datos vexilológicos...
            </p>
          </div>
        ) : (
          <>
            {/* View 1: Gallery */}
            {viewMode === 'gallery' && (
              <FlagsGallery
                countries={countries}
                onSelectCountry={handleOpenDetails}
                onCompareWith={handleCompareWith}
                onUpgradePro={(plan) => {
                  setSubModalInitialPlan(plan || 'annual');
                  setIsSubModalOpen(true);
                }}
                onOpenPdfModal={handleOpenPdfModal}
                onOpenAmazonKdpModal={() => setIsAmazonKdpModalOpen(true)}
              />
            )}

            {/* View 2: Comparator */}
            {viewMode === 'comparator' && (
              <FlagComparator
                countries={countries}
                initialSelectedCountries={
                  comparisonSelectedCountries.length >= 2
                    ? comparisonSelectedCountries
                    : [countries[0], countries[1] || countries[0]]
                }
                initialSelection={
                  comparisonSelectedCountries.length >= 2
                    ? comparisonSelectedCountries
                    : [countries[0], countries[1] || countries[0]]
                }
                onOpenDetails={handleOpenDetails}
              />
            )}

            {/* View 4: Flag Quiz & Vexillology Trivia */}
            {viewMode === 'quiz' && (
              <FlagQuiz
                countries={countries}
                onSelectCountry={handleOpenDetails}
              />
            )}

            {/* View 5: Flag Creator Studio */}
            {viewMode === 'creator' && <FlagCreator />}

            {/* View 6: Vexillology Guide & Historical Facts */}
            {viewMode === 'vexillology' && <VexillologyGuide />}
          </>
        )}
      </main>

      {/* Flag Deep-Dive Modal */}
      <FlagDetailModal
        isOpen={isModalOpen}
        country={selectedCountry}
        allCountries={countries}
        onClose={() => setIsModalOpen(false)}
        onCompareWith={handleCompareWith}
        onOpenPdfModal={handleOpenPdfModal}
      />

      {/* Subscription Pricing Modal */}
      <SubscriptionModal
        isOpen={isSubModalOpen}
        onClose={() => setIsSubModalOpen(false)}
        initialPlan={subModalInitialPlan}
      />

      {/* Country PDF Sheet Modal (2-Page Papel Bond / Letter) */}
      <CountryPdfModal
        isOpen={isPdfModalOpen}
        initialCountry={pdfSelectedCountry}
        allCountries={countries}
        onClose={() => setIsPdfModalOpen(false)}
        onOpenAmazonKdpModal={() => setIsAmazonKdpModalOpen(true)}
      />

      {/* Amazon KDP Auto-Publishing & Complete Book Compiler Modal */}
      <AmazonKdpPublishModal
        isOpen={isAmazonKdpModalOpen}
        countries={countries}
        onClose={() => setIsAmazonKdpModalOpen(false)}
      />

      {/* Sell App & Full Source Code ZIP Package Modal */}
      <SellAppModal
        isOpen={isSellModalOpen}
        onClose={() => setIsSellModalOpen(false)}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-900 px-4 py-5 text-center text-xs text-slate-500 bg-slate-950 flex flex-col sm:flex-row items-center justify-between gap-3 max-w-7xl mx-auto w-full">
        <p>
          MundoBanderas • Enciclopedia Vexilológica y Sistema de Publicación Editorial para Amazon KDP
        </p>
        <div className="flex items-center gap-4 text-[11px]">
          <button
            onClick={() => setIsSellModalOpen(true)}
            className="text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer flex items-center gap-1"
          >
            <Package className="w-3 h-3" />
            <span>Descargar ZIP para Vender App</span>
          </button>
          <span className="text-slate-700">•</span>
          <button
            onClick={() => setIsAmazonKdpModalOpen(true)}
            className="text-amber-400 hover:text-amber-300 font-semibold cursor-pointer flex items-center gap-1"
          >
            <ShoppingBag className="w-3 h-3" />
            <span>Compilar para Amazon KDP</span>
          </button>
          <span className="text-slate-700">•</span>
          <button
            onClick={() => {
              setSubModalInitialPlan('annual');
              setIsSubModalOpen(true);
            }}
            className="text-slate-400 hover:text-white cursor-pointer"
          >
            Planes Pro
          </button>
          <span className="text-slate-700">•</span>
          <span>Términos y Privacidad</span>
        </div>
      </footer>
    </div>
  );
}
